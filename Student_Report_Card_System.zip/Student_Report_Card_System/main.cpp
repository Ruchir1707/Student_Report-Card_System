#include <iostream>
#include "Project.h"

using namespace std;

int main()
{
    //cout << "Kindly maximize the output window to have a greater experience...." << endl;
    system("COLOR 71");

    Project p(10);

    cout << "                                                                    ==================================" << endl;
    cout << "                                                                    ~: STUDENT REPORT CARD SYSTEM :~ " << endl;
    cout << "                                                                    ==================================" << endl << endl;
    int option = 0;

    while (option != 4)
    {
        cout << "====================================================" << endl;
        cout << "You have the following options to continue with...." << endl ;
        cout << "Enter..." << endl;
        cout << "...1 to continue with Entry section." << endl;
        cout << "...2 to continue with Edit and delete Section." << endl;
        cout << "...3 to continue with Result Section." << endl;
        cout << "...4 to exit..." << endl;
        cout << "====================================================" << endl << endl;

        cout << "Enter your option that you want to continue with: ";
        cin >> option;
        cout << endl;

        system("cls");

        switch (option)
        {
        case 1:
            p.enter();
            break;

        case 2:
            p.edit_delete();
            break;

        case 3:
            p.result();
            break;

        case 4:
            break;

        default:
            cout << "Enter a valid option if you want to still continue or enter 4 to exit...." << endl;
        }
    }

    p.write_file();

    return 0;
}
